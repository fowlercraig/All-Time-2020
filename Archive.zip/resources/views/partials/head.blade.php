<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  @php wp_head() @endphp
  <link rel="stylesheet" href="https://rsms.me/inter/inter.css">
  <script async type="text/javascript" src="https://static.klaviyo.com/onsite/js/klaviyo.js?company_id=n5CVUT"></script>
</head>
