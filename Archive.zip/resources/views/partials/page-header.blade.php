<div class="page-header py-8">
  <h1 class="font-bold text-3xl">{!! App::title() !!}</h1>
</div>
