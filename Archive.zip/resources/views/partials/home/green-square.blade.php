<svg viewBox="0 0 230 230" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<!-- Generator: Sketch 64 (93537) - https://sketch.com -->
<title>Rectangle</title>
<desc>Created with Sketch.</desc>
<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<rect id="Rectangle" fill="#245250" transform="translate(115.457031, 114.741583) rotate(-45.000000) translate(-115.457031, -114.741583) " x="34.4570312" y="33.7415833" width="162" height="162"></rect>
</g>
</svg>